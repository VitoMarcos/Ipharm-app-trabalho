package com.example.ipharmcompose.RemedioData

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class RemedioViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: RemedioRepository
    val todosRemedios: LiveData<List<Remedio>>

    init {
        val remedioDao = RemedioDatabase.getDatabase(application).remedioDao()
        repository = RemedioRepository(remedioDao)
        todosRemedios = repository.readAllData
    }

    fun addRemedio(remedio: Remedio) {
        viewModelScope.launch {
            repository.addRemedio(remedio)
        }
    }

    fun getRemedioById(id: Int): Remedio? {
        return todosRemedios.value?.find { it.id == id }
    }
}
