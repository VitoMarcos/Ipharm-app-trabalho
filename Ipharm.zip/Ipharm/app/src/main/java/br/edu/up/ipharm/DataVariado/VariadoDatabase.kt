package br.edu.up.ipharm.DataRemedio

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import br.edu.up.ipharm.DataVariado.Variado

@Database(entities = [Variado::class], version = 1, exportSchema = false)
abstract class VariadoDatabase : RoomDatabase() {

    abstract fun variadoDao(): VariadoDao

    companion object{

        @Volatile
        private var INSTANCE: VariadoDatabase? = null

        fun getDatabase(context: Context): VariadoDatabase {
            val tempInstance = INSTANCE
            if(tempInstance != null){
                return tempInstance
            }

            synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VariadoDatabase::class.java,
                    "tabela_variado"
                ).fallbackToDestructiveMigration().build()

                INSTANCE = instance
                return instance

            }



        }


    }


}