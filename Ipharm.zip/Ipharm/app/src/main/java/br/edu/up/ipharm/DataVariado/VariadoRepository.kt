package br.edu.up.ipharm.DataRemedio

import androidx.lifecycle.LiveData
import br.edu.up.ipharm.DataVariado.Variado

class VariadoRepository(private val variadoDao: VariadoDao) {

    val readAllData: LiveData<List<Variado>> = variadoDao.readAllData()


    suspend fun addVariado(variado: Variado){
        variadoDao.addVariado(variado)
    }

    suspend fun updateVariado(variado: Variado){
        variadoDao.updateVariado(variado)
    }

    suspend fun deleteVariado(variado: Variado){
        variadoDao.deleteVariado(variado)
    }

    suspend fun deleteAll(){
        variadoDao.deleteAll()
    }

}