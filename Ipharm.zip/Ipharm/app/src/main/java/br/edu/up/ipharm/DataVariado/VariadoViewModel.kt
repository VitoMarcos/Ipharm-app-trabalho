package br.edu.up.ipharm.DataRemedio

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.livedata.ktx.R
import androidx.lifecycle.viewModelScope
import br.edu.up.ipharm.DataVariado.Variado
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class VariadoViewModel(application: Application): AndroidViewModel(application) {

    val readAllData: LiveData<List<Variado>>
    private val repository: VariadoRepository

    init {
        val variadoDao = VariadoDatabase.getDatabase(application).variadoDao()
        repository = VariadoRepository(variadoDao)
        readAllData = repository.readAllData
    }

    fun addVariado(variado: Variado){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addVariado(variado)
        }
    }

    fun updateVariado(variado: Variado){
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateVariado(variado)
        }
    }

    fun deleteVariado(variado: Variado){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteVariado(variado)
        }
    }

    fun deleteAll(){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAll()
        }
    }

}