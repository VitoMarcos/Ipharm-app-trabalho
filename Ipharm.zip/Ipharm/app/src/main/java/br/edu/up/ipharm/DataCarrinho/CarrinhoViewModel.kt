package br.edu.up.ipharm.DataRemedio

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.livedata.ktx.R
import androidx.lifecycle.viewModelScope
import br.edu.up.ipharm.DataCarrinho.CarrinhoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class CarrinhoViewModel(application: Application): AndroidViewModel(application) {

    val readAllData: LiveData<List<CarrinhoItem>>
    private val repository: CarrinhoRepository

    init {
        val carrinhoDao = CarrinhoDatabase.getDatabase(application).carrinhoDao()
        repository = CarrinhoRepository(carrinhoDao)
        readAllData = repository.readAllData
    }

    fun addCarrinho(carrinho: CarrinhoItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.addCarrinho(carrinho)
        }
    }

    fun updateCarrinho(carrinho: CarrinhoItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateCarrinho(carrinho)
        }
    }

    fun deleteCarrinho(carrinho: CarrinhoItem){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteCarrinho(carrinho)
        }
    }

    fun deleteAll(){
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAll()
        }
    }

}