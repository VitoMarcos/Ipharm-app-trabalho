package br.edu.up.ipharm

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.edu.up.ipharm.DataCarrinho.CarrinhoAdapter
import br.edu.up.ipharm.DataRemedio.CarrinhoViewModel

class CarrinhoActivity : AppCompatActivity() {

    private lateinit var recyclerCarrinho: RecyclerView
    private val carrinhoViewModel: CarrinhoViewModel by viewModels()
    private lateinit var carrinhoAdapter: CarrinhoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_carrinho)

        recyclerCarrinho = findViewById(R.id.recyclerCarrinho)

        // Configurar o adapter com o layout e ações
        carrinhoAdapter = CarrinhoAdapter(emptyList(),
            onDeleteClick = { item ->
                carrinhoViewModel.deleteCarrinho(item)
                Toast.makeText(this, "${item.nome} removido do carrinho!", Toast.LENGTH_SHORT).show()
            }
        )

        recyclerCarrinho.adapter = carrinhoAdapter
        recyclerCarrinho.layoutManager = LinearLayoutManager(this)

        // Observar a lista de itens do carrinho
        carrinhoViewModel.readAllData.observe(this) { itens ->
            carrinhoAdapter.lista = itens
            carrinhoAdapter.notifyDataSetChanged()
        }
    }
}
