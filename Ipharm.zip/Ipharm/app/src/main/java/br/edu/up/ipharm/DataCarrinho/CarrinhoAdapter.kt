package br.edu.up.ipharm.DataCarrinho

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.edu.up.ipharm.R

class CarrinhoAdapter(
    var lista: List<CarrinhoItem>,
    private val onDeleteClick: (CarrinhoItem) -> Unit
) : RecyclerView.Adapter<CarrinhoAdapter.CarrinhoViewHolder>() {

    inner class CarrinhoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nome: TextView = itemView.findViewById(R.id.textNome2)
        val msg: TextView = itemView.findViewById(R.id.textMsg2)
        val img: ImageView = itemView.findViewById(R.id.imgFoto2)
        val deleteButton: Button = itemView.findViewById(R.id.btnDeletar)

        fun bind(item: CarrinhoItem) {
            nome.text = item.nome
            msg.text = item.msg
            item.img?.let { img.setImageResource(it) }
            deleteButton.setOnClickListener { onDeleteClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarrinhoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_carrinho, parent, false)
        return CarrinhoViewHolder(view)
    }

    override fun onBindViewHolder(holder: CarrinhoViewHolder, position: Int) {
        holder.bind(lista[position])
    }

    override fun getItemCount() = lista.size
}
