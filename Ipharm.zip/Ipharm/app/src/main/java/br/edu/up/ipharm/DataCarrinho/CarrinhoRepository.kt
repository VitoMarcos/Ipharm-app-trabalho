package br.edu.up.ipharm.DataRemedio

import androidx.lifecycle.LiveData
import br.edu.up.ipharm.DataCarrinho.CarrinhoItem

class CarrinhoRepository(private val carrinhoDao: CarrinhoDao) {

    val readAllData: LiveData<List<CarrinhoItem>> = carrinhoDao.readAllData()


    suspend fun addCarrinho(carrinho: CarrinhoItem){
        carrinhoDao.addCarrinho(carrinho)
    }

    suspend fun updateCarrinho(carrinho: CarrinhoItem){
        carrinhoDao.updateCarrinho(carrinho)
    }

    suspend fun deleteCarrinho(carrinho: CarrinhoItem){
        carrinhoDao.deleteCarrinho(carrinho)
    }

    suspend fun deleteAll(){
        carrinhoDao.deleteAll()
    }

}