package br.edu.up.ipharm.DataRemedio

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import br.edu.up.ipharm.DataVariado.Variado

@Dao
interface VariadoDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addVariado(variado: Variado)

    @Update
    suspend fun updateVariado(variado: Variado )

    @Delete
    suspend fun deleteVariado(variado: Variado )

    @Query("DELETE FROM tabela_variado")
    suspend fun deleteAll()

    @Query("SELECT * FROM tabela_variado ORDER BY nomeVariado ASC")
    fun readAllData(): LiveData<List<Variado>>

}