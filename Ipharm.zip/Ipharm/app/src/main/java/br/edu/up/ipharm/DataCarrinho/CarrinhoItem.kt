package br.edu.up.ipharm.DataCarrinho

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import br.edu.up.ipharm.DataRemedio.Remedio
import br.edu.up.ipharm.DataVariado.Variado
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "tabela_carrinho")
data class CarrinhoItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int?,
    val nome: String,
    val msg: String,
    val img: Int?,
    val tipo: String // "remedio" ou "variado"
): Parcelable


