package br.edu.up.ipharm.DataRemedio

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import br.edu.up.ipharm.DataCarrinho.CarrinhoItem

@Database(entities = [CarrinhoItem::class], version = 2, exportSchema = false)
abstract class CarrinhoDatabase : RoomDatabase() {

    abstract fun carrinhoDao(): CarrinhoDao

    companion object{

        @Volatile
        private var INSTANCE: CarrinhoDatabase? = null

        fun getDatabase(context: Context): CarrinhoDatabase {
            val tempInstance = INSTANCE
            if(tempInstance != null){
                return tempInstance
            }

            synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CarrinhoDatabase::class.java,
                    "tabela_carrinho"
                ).fallbackToDestructiveMigration().build()

                INSTANCE = instance
                return instance

            }



        }


    }


}