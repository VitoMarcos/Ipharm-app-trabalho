package br.edu.up.ipharm.fragmentos

import android.os.Bundle
import android.os.Parcel
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.edu.up.ipharm.DataCarrinho.CarrinhoItem
import br.edu.up.ipharm.DataRemedio.CarrinhoDao
import br.edu.up.ipharm.DataRemedio.CarrinhoDatabase
import br.edu.up.ipharm.DataRemedio.Remedio
import br.edu.up.ipharm.DataRemedio.RemedioViewModel
import br.edu.up.ipharm.DataRemedio.RemediosAdapter
import br.edu.up.ipharm.DataRemedio.VariadoAdapter
import br.edu.up.ipharm.DataRemedio.VariadoViewModel
import br.edu.up.ipharm.R
import br.edu.up.ipharm.DataVariado.Variado
import kotlinx.coroutines.launch


class fragVariado() : Fragment(){

    lateinit var rvVariado: RecyclerView
    private lateinit var variadoViewModel: VariadoViewModel
    private lateinit var carrinhoDao: CarrinhoDao

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        variadoViewModel = ViewModelProvider(this).get(VariadoViewModel::class.java)
        val view = inflater.inflate(
            R.layout.frag_variado,
            container,
            false
        )

        carrinhoDao = CarrinhoDatabase.getDatabase(requireContext()).carrinhoDao()

        rvVariado = view.findViewById(R.id.listVariados)

        val variados = listOf(
            Variado(1, "Gilette", null, "Aparelho de barbear"),
            Variado(2, "Creatina", R.drawable.img_7, "Suplemento"),
            Variado(3, "Band-Aid", R.drawable.img_9, "Proteger ferimentos"),
            Variado(4, "Cotonete", R.drawable.img_10, "cotonete."),
            Variado(5, "Acetona", R.drawable.img_11, "Remoção de esmaltes."),
            Variado(6, "Toddynho", R.drawable.img_12, "Toddynho.")
        )

        rvVariado.adapter = VariadoAdapter(
            variados,
            onImageClick = { variado ->
                val carrinhoItem = CarrinhoItem(
                    id = variado.id,
                    nome = variado.nomeVariado,
                    msg = variado.msgVariado,
                    img = variado.fotoVariado,
                    tipo = "variado"
                )
                adicionarAoCarrinho(carrinhoItem)
            },
            onDeleteClick = { variado ->

            }
        )


        rvVariado.layoutManager = LinearLayoutManager(requireContext())

        return view
    }


    fun adicionarAoCarrinho(item: CarrinhoItem) {
        viewLifecycleOwner.lifecycleScope.launch {
            carrinhoDao.addCarrinho(item)
            Toast.makeText(requireContext(), "${item.nome} adicionado ao carrinho", Toast.LENGTH_SHORT).show()
        }
    }
    }


