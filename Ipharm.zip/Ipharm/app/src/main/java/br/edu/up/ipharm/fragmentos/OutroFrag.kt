package br.edu.up.ipharm.fragmentos

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.edu.up.ipharm.DataCarrinho.CarrinhoItem
import br.edu.up.ipharm.DataRemedio.CarrinhoDao
import br.edu.up.ipharm.DataRemedio.CarrinhoDatabase
import br.edu.up.ipharm.R
import br.edu.up.ipharm.DataRemedio.Remedio
import br.edu.up.ipharm.DataRemedio.RemedioViewModel
import br.edu.up.ipharm.DataRemedio.RemediosAdapter
import kotlinx.coroutines.launch


class OutroFrag : Fragment() {

    lateinit var rvRemedio: RecyclerView
    private lateinit var remedioViewModel: RemedioViewModel
    private lateinit var carrinhoDao: CarrinhoDao
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        remedioViewModel = ViewModelProvider(this).get(RemedioViewModel::class.java)
        val view = inflater.inflate(
            R.layout.fragment_outrofrag,
            container,
            false
        )

        carrinhoDao = CarrinhoDatabase.getDatabase(requireContext()).carrinhoDao()

        rvRemedio = view.findViewById(R.id.listRemedios)

        val remedios = listOf(
            Remedio(1, "Paracetamol", null, "Dor de cabeça"),
            Remedio(2, "Benegripe", R.drawable.img_3, "Gripe"),
            Remedio(3, "Dipirona", R.drawable.img_4, "Dores"),
            Remedio(4, "Clonazepam", R.drawable.img_5, "Alguma coisa"),
            Remedio(5, "Omeprazol", R.drawable.img_6, "Alguma coisa também"),
            Remedio(6, "Imosec", R.drawable.img_2, "Estômago")

        )

        rvRemedio.adapter = RemediosAdapter(
            remedios,
            onImageClick = { remedio ->
                val carrinhoItem = CarrinhoItem(
                    id = remedio.id,
                    nome = remedio.nome,
                    msg = remedio.msg,
                    img = remedio.foto,
                    tipo = "remedio"
                )
                adicionarAoCarrinho(carrinhoItem)
            },
            onDeleteClick = { remedio ->

            }
        )


        rvRemedio.layoutManager = LinearLayoutManager(requireContext())

        return view
    }

    fun adicionarAoCarrinho(item: CarrinhoItem) {
        viewLifecycleOwner.lifecycleScope.launch {
            carrinhoDao.addCarrinho(item)
            Toast.makeText(requireContext(), "${item.nome} adicionado ao carrinho", Toast.LENGTH_SHORT).show()
        }
    }

}