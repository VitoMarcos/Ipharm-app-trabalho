package br.edu.up.ipharm.DataVariado

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "tabela_variado")
data class Variado(
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val nomeVariado: String,
    val fotoVariado: Int?,
    val msgVariado : String
): Parcelable
