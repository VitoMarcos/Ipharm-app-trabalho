package br.edu.up.ipharm.DataRemedio

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import br.edu.up.ipharm.DataVariado.Variado
import br.edu.up.ipharm.R

class VariadoAdapter(
    var lista: List<Variado>,
    private val onImageClick: (Variado) -> Unit, private val onDeleteClick: (Variado) -> Unit): RecyclerView.Adapter<VariadoAdapter.VariadoViewHolder>() {

    inner class VariadoViewHolder(val itemVIew: View) : ViewHolder(itemVIew){


        val nomeVariado: TextView = itemView.findViewById(R.id.textViewNomeVariado)
        val msgVariado: TextView = itemView.findViewById(R.id.textViewMensagem)
        val imgVariado: ImageView = itemView.findViewById(R.id.imageViewVariado)



    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VariadoViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemView = layoutInflater.inflate(R.layout.item_lista_variados,parent,false)

        return VariadoViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return lista.size
    }

    override fun onBindViewHolder(VariadoHolder : VariadoViewHolder, position: Int) {

        val variado = lista[position]
        VariadoHolder.nomeVariado.text = variado.nomeVariado
        VariadoHolder.msgVariado.text = variado.msgVariado
        if (variado.fotoVariado != null) {
            VariadoHolder.imgVariado.setImageResource(variado.fotoVariado)
        } else {
            VariadoHolder.imgVariado.setImageResource(R.drawable.img_8)
        }


        VariadoHolder.imgVariado.setOnClickListener {
            onImageClick(variado)
        }

    }

    fun updateList(novaLista: List<Variado>) {
        lista = novaLista
        notifyDataSetChanged()
    }


}