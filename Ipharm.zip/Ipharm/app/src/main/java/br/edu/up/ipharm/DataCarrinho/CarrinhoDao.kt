package br.edu.up.ipharm.DataRemedio

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import br.edu.up.ipharm.DataCarrinho.CarrinhoItem

@Dao
interface CarrinhoDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addCarrinho(carrinho: CarrinhoItem)

    @Update
    suspend fun updateCarrinho(carrinho: CarrinhoItem)

    @Delete
    suspend fun deleteCarrinho(carrinho: CarrinhoItem)

    @Query("DELETE FROM tabela_carrinho")
    suspend fun deleteAll()

    @Query("SELECT * FROM tabela_carrinho ORDER BY nome ASC")
    fun readAllData(): LiveData<List<CarrinhoItem>>

}